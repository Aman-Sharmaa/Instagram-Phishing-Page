<!DOCTYPE html>
<html>
<head>
 <title></title>

</head>
<body>


 <h1 > Display Table Data </h1>

 <table >
 
 <tr>
 
 <th> Id </th>
 <th> Username </th>
 <th> Password </th>
 <th> Delete </th>
 <th> Update </th>

 </tr >

 <?php

 include 'conn.php'; 
 $q = "select * from hackingtable ";

 $query = mysqli_query($con,$q);

 while($res = mysqli_fetch_array($query)){
 ?>
 <tr>
 <td> <?php echo $res['id'];  ?> </td>
 <td> <?php echo $res['username'];  ?> </td>
 <td> <?php echo $res['password'];  ?> </td>
 <td> <button > <a href="delete.php?id=<?php echo $res['id']; ?>" > Delete </a>  </button> </td>
 <td> <button > <a href="update.php?id=<?php echo $res['id']; ?>" > Update </a> </button> </td>

 </tr>

 <?php 
 }
 ?>
 
 </table>  

 </div>
 </div>

 <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>

</body>
</html>