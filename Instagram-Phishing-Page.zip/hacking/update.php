 <?php

 include 'conn.php';

 if(isset($_POST['done'])){

 $id = $_GET['id'];
 $username = $_POST['username'];
 $password = $_POST['password'];
 $q = " update hackingtable set id=$id, username='$username', password='$password' where id=$id  ";

 $query = mysqli_query($con,$q);

 header('location:display.php');
 }

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

</head>
<body>

 <div >
 
 <form method="post">
 
 <br><br><div class="card">
 
 <div >
 <h1 >  Update Operation </h1>
 </div><br>

 <label> Username: </label>
 <input type="text" name="username" > <br>

 <label> Password: </label>
 <input type="text" name="password" class="form-control"> <br>

 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>

 </div>
 </form>
 </div>
</body>
</html>